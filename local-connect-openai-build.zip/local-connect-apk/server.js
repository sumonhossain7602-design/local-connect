// LOCAL CONNECT AI backend
// Keeps OPENAI_API_KEY off the Android app.
// Node.js 18+ required.
const http = require('http');

const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

function send(res,status,body){
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,OPTIONS'});
  res.end(JSON.stringify(body));
}
function readBody(req){
  return new Promise((resolve,reject)=>{
    let data='';
    req.on('data',c=>{data+=c; if(data.length>100000) req.destroy();});
    req.on('end',()=>{try{resolve(JSON.parse(data||'{}'))}catch(e){reject(e)}});
    req.on('error',reject);
  });
}
function outputText(data){
  if(typeof data.output_text==='string') return data.output_text;
  const parts=[];
  for(const item of (data.output||[])){
    for(const c of (item.content||[])){
      if(c.type==='output_text' && c.text) parts.push(c.text);
    }
  }
  return parts.join('\n').trim();
}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS') return send(res,204,{});
  if(req.method==='GET' && req.url==='/health') return send(res,200,{ok:true,service:'local-connect-ai'});
  if(req.method!=='POST' || req.url!=='/api/ai/chat') return send(res,404,{error:'Not found'});
  if(!OPENAI_API_KEY) return send(res,500,{error:'OPENAI_API_KEY is not configured on the backend.'});
  try{
    const {message}=await readBody(req);
    if(!message || typeof message!=='string') return send(res,400,{error:'message is required'});
    const input = [
      {role:'system',content:[{type:'input_text',text:'You are the helpful AI assistant for LOCAL CONNECT, a local marketplace app. Help users understand local services, products, listings, requirements, quotes, and app usage. Do not invent real provider availability, prices, addresses, or bookings. If current local data is unavailable, say so.'}]},
      {role:'user',content:[{type:'input_text',text:message.slice(0,6000)}]}
    ];
    const r=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${OPENAI_API_KEY}`},
      body:JSON.stringify({model:MODEL,input})
    });
    const data=await r.json();
    if(!r.ok) return send(res,r.status,{error:data.error?.message||'OpenAI API request failed'});
    return send(res,200,{answer:outputText(data)});
  }catch(e){ return send(res,500,{error:e.message||'Server error'}); }
});
server.listen(PORT,()=>console.log(`LOCAL CONNECT AI backend listening on http://localhost:${PORT}`));
