# LOCAL CONNECT — Android + OpenAI AI

This project is an Expo/React Native LOCAL CONNECT app with a secure OpenAI-powered AI helper.

## What was added

- `AI Assistant` screen in the mobile app.
- `server.js` backend proxy for OpenAI Responses API.
- The OpenAI API key is read only from the backend environment.
- `EXPO_PUBLIC_API_URL` tells the Android app where the backend is hosted.
- `/health` endpoint for a quick backend test.

## 1. Backend setup

Use Node.js 18+.

```bash
cp .env.example .env
```

Put your OpenAI API key in `.env`:

```text
OPENAI_API_KEY=YOUR_KEY
OPENAI_MODEL=gpt-5.6-luna
PORT=3000
```

Start the backend:

```bash
npm run server
```

Test:

```text
http://YOUR_SERVER:3000/health
```

## 2. Connect the Android app

Create an environment variable for the Expo build:

```text
EXPO_PUBLIC_API_URL=https://YOUR-BACKEND-DOMAIN
```

Do NOT put `OPENAI_API_KEY` in the Expo app.

For local phone testing, `localhost` means the phone itself. Use your computer's LAN IP, for example:

```text
EXPO_PUBLIC_API_URL=http://192.168.1.10:3000
```

For production, use HTTPS.

## 3. Build APK

```bash
npm install
npm run build:apk
```

## 4. Build AAB

```bash
npx eas build --platform android --profile production
```

The backend must be deployed separately; an APK/AAB does not run the Node backend by itself.

## Important

The AI helper is a foundation. To make LOCAL CONNECT actually answer using live listings, providers, bookings, and quotes, connect the backend to your real database/API and pass only the relevant authorized data to the AI.
