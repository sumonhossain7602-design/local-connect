# LOCAL CONNECT — Android APK project

This project contains the supplied LOCAL CONNECT React Native app and the configuration needed to build an Android APK with Expo/EAS.

## Build APK

1. Install Node.js and Git.
2. In this folder run:
   npm install
3. Install/login to EAS:
   npx eas-cli login
4. Build an APK:
   npm run build:apk

EAS will provide the APK build link when the remote Android build finishes.

## Test locally
npm start

Then open it in Expo Go or an Android emulator.
