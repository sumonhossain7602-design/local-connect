import React, { useState } from "react";
import { SafeAreaView, View, Text, TextInput, Pressable, StyleSheet, ScrollView, Alert } from "react-native";
import { StatusBar } from "expo-status-bar";

export default function App() {
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("Hi! Local Connect is ready.");
  const send = async () => {
    if (!message.trim()) return;
    setReply("Message received. Connect your secure backend to enable AI replies.");
    setMessage("");
  };
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Local Connect</Text>
        <Text style={styles.subtitle}>Connect • Chat • AI</Text>
        <View style={styles.card}>
          <Text style={styles.label}>Assistant</Text>
          <Text style={styles.reply}>{reply}</Text>
        </View>
        <TextInput
          value={message}
          onChangeText={setMessage}
          placeholder="Type a message..."
          style={styles.input}
        />
        <Pressable style={styles.button} onPress={send}>
          <Text style={styles.buttonText}>Send</Text>
        </Pressable>
        <View style={styles.card}>
          <Text style={styles.label}>Build status</Text>
          <Text style={styles.small}>Android APK ready to build with Codemagic.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:"#f7f9fc"},
  container:{padding:22,gap:14},
  title:{fontSize:32,fontWeight:"800",marginTop:20},
  subtitle:{fontSize:16,color:"#667085",marginBottom:12},
  card:{backgroundColor:"#fff",padding:18,borderRadius:16,elevation:2},
  label:{fontSize:14,fontWeight:"700",marginBottom:8},
  reply:{fontSize:16,lineHeight:24},
  small:{fontSize:14,color:"#667085"},
  input:{backgroundColor:"#fff",borderWidth:1,borderColor:"#d0d5dd",borderRadius:14,padding:15,fontSize:16},
  button:{backgroundColor:"#111827",padding:16,borderRadius:14,alignItems:"center"},
  buttonText:{color:"#fff",fontSize:16,fontWeight:"700"}
});