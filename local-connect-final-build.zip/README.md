# Local Connect

Expo/React Native Android project prepared for Codemagic APK builds.

## GitHub root
Keep `package.json`, `App.js`, `app.json`, `server.js`, and `codemagic.yaml` directly in the repository root.
