// Secure backend placeholder.
// Keep OPENAI_API_KEY on the server, never inside the mobile app.
// Add your production API route here before enabling real AI requests.
const http = require("http");
const port = process.env.PORT || 3000;
http.createServer((req,res)=>{
  res.writeHead(200, {"Content-Type":"application/json"});
  res.end(JSON.stringify({ok:true, service:"Local Connect backend"}));
}).listen(port, ()=>console.log(`Server listening on ${port}`));